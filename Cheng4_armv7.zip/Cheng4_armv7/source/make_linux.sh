g++ -s -Wall -Wpedantic -W -O4 -std=c++0x -fno-stack-protector -fomit-frame-pointer -fno-rtti -fno-exceptions -fexpensive-optimizations -DNDEBUG -U_FORTIFY_SOURCE -static allinone.cpp -o cheng4_linux_x64 -lpthread

