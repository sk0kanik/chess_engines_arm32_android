#!/bin/bash

clang-format-11 -style=file -i src/include/*.h src/sources/*.c