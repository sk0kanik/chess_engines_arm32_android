#!/bin/sh

ln -s ../../scripts/commit-msg.sh .git/hooks/commit-msg