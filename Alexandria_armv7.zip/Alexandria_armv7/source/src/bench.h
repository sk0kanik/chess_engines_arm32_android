#pragma once

// starts a bench for alexandria, searching a set of positions up to a set depth
void StartBench();
