#pragma once

void RunTests();
