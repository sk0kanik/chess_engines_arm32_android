#pragma once

struct S_MOVELIST;

void PickMove(S_MOVELIST* move_list, const int moveNum);
